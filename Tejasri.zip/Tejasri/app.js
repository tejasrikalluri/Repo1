var portfolio = document.getElementById("portfolio");
var home = document.getElementById("home");
var about = document.getElementById("about");
var contact = document.getElementById("contact");

portfolio.style.display = "none";
about.style.display = "none";
contact.style.display = "none";
function showHome() {
    alert("You clicked home page")

    home.style.display = "block";
    portfolio.style.display = "none";
    about.style.display = "none";
    contact.style.display = "none";
}
function displayPortfolioPage() {
    alert("You clicked portfolio page")
    home.style.display = "none";
    portfolio.style.display = "block";
    about.style.display = "none";
    contact.style.display = "none";
}
function displayAboutPage() {
    alert("You clicked about page")
    home.style.display = "none";
    portfolio.style.display = "none";
    about.style.display = "block";
    contact.style.display = "none";
}
function displayContactPage() {
    alert("You clicked contact page")
    home.style.display = "none";
    portfolio.style.display = "none";
    about.style.display = "none";
    contact.style.display = "block";

}