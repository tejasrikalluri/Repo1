var portfolio = document.getElementById("portfolio");
var home = document.getElementById("home");
var about = document.getElementById("about");
var contact = document.getElementById("contact");
var sample = document.getElementById("sample");

portfolio.style.display = "none";
about.style.display = "none";
contact.style.display = "none";
sample.style.display = "block";
function showHome() {
    home.style.display = "block";
    portfolio.style.display = "none";
    about.style.display = "none";
    contact.style.display = "none";
    displaySimpleBlock();
}
function displayPortfolioPage() {
    home.style.display = "none";
    portfolio.style.display = "block";
    about.style.display = "none";
    contact.style.display = "none";
    displaySimpleBlock();
}
function displayAboutPage() {
    home.style.display = "none";
    portfolio.style.display = "none";
    about.style.display = "block";
    contact.style.display = "none";
    sample.style.display = "block";
    sample.classList.add("heightadjust");
    sample.classList.remove("sample");
}
function displayContactPage() {
    home.style.display = "none";
    portfolio.style.display = "none";
    about.style.display = "none";
    contact.style.display = "block";
}
function displaySimpleBlock() {
    sample.style.display = "block";
    sample.classList.add("sample");
    sample.classList.remove("heightadjust");

}